CREATE TABLE HangSX ( 
 MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY, 
 TenHang VARCHAR2(30) NOT NULL, 
 DiaChi VARCHAR2(50), 
 SoDT VARCHAR2(15),
 Email VARCHAR2(50) 
); 
CREATE TABLE SanPham ( 
 MaSP VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY, 
 MaHangSX VARCHAR2(10) REFERENCES HangSX(MaHangSX), 
 TenSP VARCHAR2(50) NOT NULL, 
 SoLuong NUMBER(10), 
 MauSac VARCHAR2(20), 
 GiaBan NUMBER(15,2), 
 DonViTinh VARCHAR2(15), 
 MoTa CLOB 
); 
CREATE TABLE NhanVien ( 
 MaNV VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY, 
 TenNV VARCHAR2(50) NOT NULL, 
 GioiTinh VARCHAR2(10), 
 DiaChi VARCHAR2(100), 
 SoDT VARCHAR2(15), 
 Email VARCHAR2(50), 
 TenPhong VARCHAR2(30) 
); 
CREATE TABLE PNhap ( 
 SoHDN VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY, 
 NgayNhap DATE, 
 MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 
CREATE TABLE Nhap ( 
 SoHDN VARCHAR2(10) REFERENCES PNhap(SoHDN), 
 MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
 SoLuongN NUMBER(10), 
 DonGiaN NUMBER(15,2), 
 CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP) 
); 
CREATE TABLE PXuat ( 
 SoHDX VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY, 
 NgayXuat DATE, 
 MaNV VARCHAR2(10) REFERENCES NhanVien(MaNV) 
); 
CREATE TABLE Xuat ( 
 SoHDX VARCHAR2(10) REFERENCES PXuat(SoHDX), 
 MaSP VARCHAR2(10) REFERENCES SanPham(MaSP), 
 SoLuongX NUMBER(10), 
 CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP) 
);

-- Phiếu bài tập 1
-- a
create or replace procedure sp_NhapHangSX(
    p_maHangSX in varchar2,
    p_tenHang in varchar2,
    p_diaChi in varchar2,
    p_soDT in varchar2,
    p_email in varchar2
) as v_dem number;
begin
    select count(*) into v_dem from HangSX where TenHang = p_tenHang;
    
    if v_dem > 0 then
        DBMS_OUTPUT.PUT_LINE('Tên hãng sản xuất đã tồn tại');
    else
        insert into HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
        values (p_maHangSX, p_tenHang, p_diaChi, p_soDT, p_email);
        DBMS_OUTPUT.PUT_LINE('Thệm hàng sản xuất thành công');
        commit;
    end if;
end sp_NhapHangSX;
/

-- b
create or replace procedure sp_NhapSP (
    p_maSP in varchar2,
    p_tenHang in varchar2,
    p_tenSP in varchar2,
    p_soLuong in number,
    p_mauSac in varchar2,
    p_giaBan IN NUMBER,
    p_donViTinh in varchar2,
    p_moTa in clob
) AS
    v_maHangSX varchar2(10);
    v_dem number;
begin
    begin
        select MaHangSX into v_maHangSX from HangSX where TenHang = p_TenHang;
    exception
        when NO_DATA_FOUND then
            DBMS_OUTPUT.PUT_LINE('Tên hãng không tồn tại');
            return;
    END;

    select count(*) into v_dem from SanPham where MaSP = p_maSP;

    if v_dem > 0 then
        update SanPham
        set MaHangSX = v_maHangSX,
            TenSP = p_tenSP,
            SoLuong = p_soLuong,
            MauSac = p_mauSac,
            GiaBan = p_giaBan,
            DonViTinh = p_donViTinh,
            MoTa = p_moTa
        where MaSP = p_maSP;
        DBMS_OUTPUT.PUT_LINE('Cap nhat thong tin san pham thanh cong!');
    else
        insert into SanPham (MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        values (p_maSP, v_maHangSX, p_tenSP, p_soLuong, p_mauSac, p_giaBan, p_donViTinh, p_moTa);
        DBMS_OUTPUT.PUT_LINE('Thêm mới sản phẩm thành công');
    end if;
    commit;
end sp_NhapSP;
/

-- c
create or replace procedure sp_xoaHangSX (
    p_tenHang in varchar2
) as
    v_maHangSX varchar2(10);
begin
    begin
        select MaHangSX into v_maHangSX from HangSX where TenHang = p_tenHang;
    exception
        when NO_DATA_FOUND then
            DBMS_OUTPUT.PUT_LINE('Tên hãng không tồn tại');
            return;
    end;

    delete from SanPham where MaHangSX = v_maHangSX;
    delete from HangSX where MaHangSX = v_maHangSX;
    DBMS_OUTPUT.PUT_LINE('Đã xoá hãng sản xuất và các sản phẩm thuộc hãng này');
    commit;
end sp_xoaHangSX;
/

-- d
create or replace procedure sp_NhapNhanVien (
    p_maNV in varchar2,
    p_tenNV in varchar2,
    p_gioiTinh in varchar2,
    p_diaChi in varchar2,
    p_soDT in varchar2,
    p_email in varchar2,
    p_tenPhong in varchar2,
    p_flag in number
) as
begin
    if p_flag = 0 then
        update NhanVien
        set TenNV = p_tenNV,
            GioiTinh = p_gioiTinh,
            DiaChi = p_diaChi,
            SoDT = p_soDT,
            Email = p_email,
            TenPhong = p_tenPhong
        where MaNV = p_maNV;
        
        DBMS_OUTPUT.PUT_LINE('Đã cập nhật thông tin nhân viên');
    else
        insert into NhanVien (MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        values (p_maNV, p_tenNV, p_gioiTinh, p_diaChi, p_soDT, p_email, p_tenPhong);
        DBMS_OUTPUT.PUT_LINE('Thêm mới nhân viên thành công');
    end if;
    commit;
end sp_NhapNhanVien;
/

-- e
create or replace procedure sp_NhapDuLieuNhap (
    p_soHDN in varchar2,
    p_maSP in varchar2,
    p_maNV in varchar2,
    p_ngayNhap in date,
    p_soLuongN in number,
    p_donGiaN in number
) as
    v_demSP number;
    v_demNV number;
    v_demHD number;
begin
    select count(*) into v_demSP from SanPham where MaSP = p_maSP;
    if v_demSP = 0 then
        DBMS_OUTPUT.PUT_LINE('Mã sản phẩn không tồn tại');
        return;
    end if;

    select count(*) into v_demNV from NhanVien where MaNV = p_maNV;
    if v_demNV = 0 then
        DBMS_OUTPUT.PUT_LINE('Mã nhân viên không tồn tại');
        return;
    end if;

    select count(*) into v_demHD from PNhap where SoHDN = p_soHDN;

    if v_demHD > 0 then
        update Nhap 
        set SoLuongN = p_soLuongN, 
            DonGiaN = p_donGiaN
        where SoHDN = p_soHDN and MaSP = p_maSP;
        DBMS_OUTPUT.PUT_LINE('Đã cập nhật chi tiết hoá đơn nhập');
    else
        insert into PNhap (SoHDN, NgayNhap, MaNV) values (p_SoHDN, p_NgayNhap, p_MaNV);
        insert into Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) values (p_soHDN, p_maSP, p_soLuongN, p_donGiaN);
        DBMS_OUTPUT.PUT_LINE('Đã thêm mới hoá đơn nhập và chi tiết');
    end if;
    commit;
end sp_NhapDuLieuNhap;
/

-- f
create or replace procedure sp_NhapDuLieuXuat (
    p_soHDX in varchar2,
    p_maSP in varchar2,
    p_maNV in varchar2,
    p_ngayXuat in date,
    p_soLuongX in number
) as
    v_demNV number;
    v_demHD number;
    v_soLuongTon number;
begin
    begin
        select SoLuong into v_soLuongTon from SanPham where MaSP = p_maSP;
    exception
        when NO_DATA_FOUND then
            DBMS_OUTPUT.PUT_LINE('Mã sản phẩm không tồn tại');
            return;
    end;

    select count(*) into v_demNV from NhanVien where MaNV = p_maNV;
    if v_demNV = 0 then
        DBMS_OUTPUT.PUT_LINE('Mã nhận viên không tồn tại');
        return;
    end if;

    if p_SoLuongX > v_soLuongTon then
        DBMS_OUTPUT.PUT_LINE('Số lượng xuất vượt quá số lượng tồn kho');
        return;
    end if;

    select count(*) into v_demHD from PXuat where SoHDX = p_soHDX;

    if v_demHD > 0 then
        update Xuat 
        set SoLuongX = p_soLuongX
        where SoHDX = p_soHDX and MaSP = p_maSP;
        DBMS_OUTPUT.PUT_LINE('Đã cập nhật chi tiết hoá đơn xuất');
    else
        insert into PXuat (SoHDX, NgayXuat, MaNV) values (p_soHDX, p_ngayXuat, p_maNV);
        insert into Xuat (SoHDX, MaSP, SoLuongX) values (p_soHDX, p_maSP, p_soLuongX);
        DBMS_OUTPUT.PUT_LINE('Đã thêm mới hoá đơn xuất và chi tiết');
    end if;
    
    commit;
end sp_NhapDuLieuXuat;
/

-- g
create or replace procedure sp_XoaNhanVien (
    p_maNV in varchar2
) as
    v_dem number;
begin
    select count(*) into v_dem from NhanVien where MaNV = p_maNV;
    if v_dem = 0 then
        DBMS_OUTPUT.PUT_LINE('Nhân viên không tồn tại');
        return;
    end if;

    delete from Nhap where SoHDN in (select SoHDN from PNhap where MaNV = p_maNV);
    delete from PNhap where MaNV = p_maNV;

    delete from Xuat where SoHDX in (select SoHDX from PXuat where MaNV = p_maNV);
    delete from PXuat where MaNV = p_maNV;

    delete from NhanVien where MaNV = p_maNV;

    DBMS_OUTPUT.PUT_LINE('Đã xoá nhân viên và toàn bộ lịch sử nhập/xuất liên quan');
    commit;
end sp_XoaNhanVien;
/

-- h
create or replace procedure sp_XoaSanPham (
    p_maSP in varchar2
) as
    v_dem number;
begin
    select count(*) into v_dem from SanPham where MaSP = p_maSP;
    if v_dem = 0 then
        DBMS_OUTPUT.PUT_LINE('Sản phẩn không tồn tại');
        return;
    end if;

    delete from Nhap where MaSP = p_maSP;
    delete from Xuat where MaSP = p_maSP;

    delete from SanPham where MaSP = p_maSP;

    DBMS_OUTPUT.PUT_LINE('Đã xoá sản phẩm và lịch sử chi tiết nhập/xuất của sản phẩm');
    commit;
end sp_XoaSanPham;
/

-- Phiếu bài tập 2
-- a
create or replace procedure sp_ThemNhanVien (
    p_maNV in varchar2,
    p_tenNV in varchar2,
    p_gioiTinh in varchar2,
    p_diaChi in varchar2,
    p_soDT in varchar2,
    p_email in varchar2,
    p_tenPhong in varchar2,
    p_flag in number,
    p_kq out number
) as
begin
    if p_gioiTinh <> 'Nam' and p_gioiTinh <> 'Nu' then
        p_kq := 1; 
        return;
    end if;

    if p_flag = 0 then
        insert into NhanVien (MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        values (p_maNV, p_tenNV, p_gioiTinh, p_diaChi, p_soDT, p_email, p_tenPhong);
    else
        update NhanVien
        set TenNV = p_tenNV,
            GioiTinh = p_gioiTinh,
            DiaChi = p_diaChi,
            SoDT = p_soDT,
            Email = p_email,
            TenPhong = p_tenPhong
        where MaNV = p_maNV;
    end if;

    p_KQ := 0;
    commit;
end sp_ThemNhanVien;
/


-- b
create or replace procedure sp_ThemMoiSP (
    p_maSP in varchar2,
    p_tenHang in varchar2,
    p_tenSP in varchar2,
    p_soLuong in number,
    p_mauSac in varchar2,
    p_giaBan in number,
    p_donViTinh in varchar2,
    p_moTa in clob,
    p_flag in number,
    p_kq out number
) as
    v_maHangSX varchar2(10);
begin
    begin
        select MaHangSX into v_maHangSX from HangSX where TenHang = p_tenHang;
    exception
        when NO_DATA_FOUND then
            p_kq := 1;
            return;
    end;

    if p_SoLuong < 0 then
        p_KQ := 2;
        return;
    end if;

    if p_Flag = 0 then
        insert into SanPham (MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        values (p_maSP, v_maHangSX, p_tenSP, p_soLuong, p_mauSac, p_giaBan, p_donViTinh, p_moTa);
    else
        update SanPham
        set MaHangSX = v_maHangSX,
            TenSP = p_tenSP,
            SoLuong = p_soLuong,
            MauSac = p_mauSac,
            GiaBan = p_giaBan,
            DonViTinh = p_donViTinh,
            MoTa = p_moTa
        where MaSP = p_maSP;
    end if;

    p_kq := 0;
    commit;
end sp_ThemMoiSP;
/

-- c
create or replace procedure sp_XoaNhanVien_Out (
    p_maNV in varchar2,
    p_kq out number
) as
    v_dem number;
begin
    select count(*) into v_dem from NhanVien where MaNV = p_maNV;
    
    if v_dem = 0 then
        p_kq := 1;
        return;
    end if;

    delete from Nhap where SoHDN in (select SoHDN from PNhap where MaNV = p_maNV);
    delete from PNhap where MaNV = p_maNV;

    delete from Xuat where SoHDX in (select SoHDX from PXuat where MaNV = p_maNV);
    delete from PXuat where MaNV = p_maNV;

    delete from NhanVien where MaNV = p_maNV;

    p_kq := 0;
    commit;
end sp_XoaNhanVien_Out;
/

-- d
create or replace procedure sp_XoaSanPham_Out (
    p_maSP in varchar2,
    p_kq out number
) as
    v_dem number;
begin
    select count(*) into v_dem from SanPham where MaSP = p_maSP;
    
    if v_dem = 0 then
        p_kq := 1;
        return;
    end if;

    delete from Nhap where MaSP = p_maSP;
    delete from Xuat where MaSP = p_maSP;

    delete from SanPham where MaSP = p_maSP;

    p_kq := 0;
    commit;
end sp_XoaSanPham_Out;
/

-- e
create or replace procedure sp_NhapHangSX_Out (
    p_maHangSX in varchar2,
    p_tenHang in varchar2,
    p_diaChi in varchar2,
    p_soDT in varchar2,
    p_email in varchar2,
    p_kq out number
) as
    v_dem number;
begin
    select count(*) into v_dem from HangSX where TenHang = p_tenHang;

    if v_dem > 0 then
        p_kq := 1;
        return;
    end if;

    insert into HangSX (MaHangSX, TenHang, DiaChi, SoDT, Email)
    values (p_maHangSX, p_tenHang, p_diaChi, p_soDT, p_email);

    p_kq := 0;
    commit;
end sp_NhapHangSX_Out;
/

-- f
create or replace procedure sp_NhapBangNhap_Out (
    p_soHDN in varchar2,
    p_maSP in varchar2,
    p_maNV in varchar2,
    p_ngayNhap in date,
    p_soLuongN in number,
    p_donGiaN in number,
    p_kq out number
) as
    v_demSP number;
    v_demNV number;
    v_demHD number;
begin
    select count(*) into v_demSP from SanPham where MaSP = p_maSP;
    if v_demSP = 0 then
        p_kq := 1;
        return;
    end if;

    select count(*) into v_demNV from NhanVien where MaNV = p_maNV;
    if v_demNV = 0 then
        p_kq := 2;
        return;
    end if;

    select count(*) into v_demHD from PNhap where SoHDN = p_soHDN;

    if v_demHD > 0 then
        update Nhap 
        set SoLuongN = p_soLuongN, 
            DonGiaN = p_donGiaN
        where SoHDN = p_soHDN and MaSP = p_maSP;
    else
        insert into PNhap (SoHDN, NgayNhap, MaNV) 
        values (p_soHDN, p_ngayNhap, p_maNV);
        
        insert into Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) 
        values (p_soHDN, p_maSP, p_soLuongN, p_donGiaN);
    end if;

    p_kq := 0;
    commit;
end sp_NhapBangNhap_Out;
/

-- g
create or replace procedure sp_NhapBangXuat_Out (
    p_soHDX in varchar2,
    p_maSP in varchar2,
    p_maNV in varchar2,
    p_ngayXuat in date,
    p_soLuongX in number,
    p_kq out number
) as
    v_demNV number;
    v_demHD number;
    v_soLuongTon number;
begin
    begin
        select SoLuong into v_soLuongTon from SanPham where MaSP = p_maSP;
    exception
        when NO_DATA_FOUND then
            p_kq := 1;
            return;
    end;

    select count(*) into v_demNV from NhanVien where MaNV = p_maNV;
    if v_demNV = 0 then
        p_kq := 2;
    end if;

    if p_soLuongX > v_soLuongTon then
        p_kq := 3;
        return;
    end if;

    select count(*) into v_demHD from PXuat where SoHDX = p_soHDX;

    if v_demHD > 0 then
        update Xuat 
        set SoLuongX = p_soLuongX
        where SoHDX = p_soHDX and MaSP = p_maSP;
    else
        insert into PXuat (SoHDX, NgayXuat, MaNV) 
        values (p_soHDX, p_ngayXuat, p_maNV);
        
        insert into Xuat (SoHDX, MaSP, SoLuongX) 
        values (p_soHDX, p_maSP, p_soLuongX);
    end if;

    p_kq := 0;
    commit;
end sp_NhapBangXuat_Out;
/

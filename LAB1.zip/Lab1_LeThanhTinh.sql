create table s_region(
    id number(7) constraint s_region_id_pk primary key,
    name varchar2(50) not null
);

create table s_title(
    title varchar2(25) constraint s_title_pk primary key
);

create table s_dept(
    id number(7) constraint s_dept_id_pk primary key,
    name varchar2(25) not null,
    region_id number(7) constraint s_dept_region_id_fk  references s_region(id)
);

create table s_emp(
    id number(7) constraint s_emp_id_pk primary key,
    last_name varchar2(25) not null,
    first_name varchar2(25),
    userid varchar2(8) unique,
    start_date date,
    comments varchar2(255),
    manager_id number(7) constraint s_emp_manager_id_fk references s_emp(id),
    title varchar2(25) constraint s_emp_title_fk references s_title(title),
    dept_id number(7) constraint dept_emp_dept_id_fk references s_dept(id),
    salary NUMBER(11,2),
    commission_pct number(4,2)
);

create table s_customer(
    id number(7) constraint s_customer_id_pk primary key,
    name varchar2(50) not null,
    phone varchar2(25),
    address varchar2(50),
    city varchar2(30),
    state varchar2(20),
    country varchar2(30),
    zip_code varchar2(15),
    credit_rating varchar2(10),
    sale_rep_id number(7) constraint s_customer_sale_rep_id_fk references s_emp(id),
    region_id number(7) constraint s_customer_region_id references s_region(id),
    comments varchar2(255)
);

create table s_warehouse(
    id number(7) constraint s_warehouse_id_pk primary key,
    region_id number(7) constraint s_warehouse_region_id_fk references s_region(id),
    address varchar2(50),
    city varchar2(30),
    state varchar2(20),
    country varchar2(30),
    zip_code varchar2(15),
    phone varchar2(25),
    manager_id number(7) constraint s_warehouse_manager_id references s_emp(id)
);

create table s_image(
    id number(7) constraint s_image_id_pk primary key,
    format varchar(25),
    user_filename varchar2(1),
    filename varchar2(50),
    image blob
);

create table s_longtext(
    id number(7) constraint s_longtext_id_pk primary key,
    user_filename varchar2(1),
    filename varchar2(50),
    text clob
);

create table s_product(
    id number(7) constraint s_product_id_pk primary key,
    name varchar2(50) not null,
    short_desc varchar2(255),
    longtext_id number(7) constraint s_product_longtext_id_fk references s_longtext(id),
    image_id number(7) constraint s_product_image_id_fk references s_image(id),
    suggested_whlsl_price number(11,2),
    whlsl_units varchar2(25)
);

create table s_ord(
    id number(7) constraint s_ord_id_pk primary key,
    customer_id number(7) constraint s_ord_customer_id_fk references s_customer(id),
    date_ordered date,
    date_shipped date,
    sale_rep_id number(7) constraint s_ord_sale_rep_id_fk references s_emp(id),
    total number(11,2),
    payment_type varchar2(25),
    order_filled varchar2(1)
);

create table s_item(
    ord_id number(7) constraint s_item_ord_id_fk references s_ord(id),
    item_id number(7),
    product_id number(7) constraint s_item_product_id_fk references s_product(id),
    price number(11,2),
    quantity number(7),
    quantity_shipped number(7),
    constraint s_item_pk primary key (ord_id, item_id)
);

create table s_inventory(
    product_id number(7) constraint s_inventory_product_id_fk references s_product(id),
    warehouse_id number(7) constraint s_inventory_warehouse_id_fk references s_warehouse(id),
    amount_in_stock number(7),
    reorder_point number(7),
    max_in_stock number(7),
    out_of_stock_explanation varchar2(255),
    restock_date date,
    constraint s_inventory_pk primary key (product_id, warehouse_id)
);

desc s_emp

-- 1. BẢNG S_REGION
insert into s_region (id, name) values (1, 'Asia');
insert into s_region (id, name) values (2, 'Europe');
insert into s_region (id, name) values (3, 'North America');
insert into s_region (id, name) values (4, 'South America');
insert into s_region (id, name) values (5, 'Africa');
insert into s_region (id, name) values (6, 'Oceania');
commit;
select * from s_region;
-- 2. BẢNG S_TITLE
insert into s_title (title) values ('President');
insert into s_title (title) values ('VP Sales');
insert into s_title (title) values ('Manager');
insert into s_title (title) values ('Sales Rep');
insert into s_title (title) values ('Clerk');
insert into s_title (title) values ('Giám đốc');
commit;
select * from s_title;
-- 3. BẢNG S_DEPT
insert into s_dept (id, name, region_id) values (10, 'Finance', 1);
insert into s_dept (id, name, region_id) values (31, 'Sales', 3);
insert into s_dept (id, name, region_id) values (42, 'Operations', 1);
insert into s_dept (id, name, region_id) values (50, 'Administration', 2);
commit;
select * from s_dept;

-- 4. BẢNG S_EMP
insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (1, 'Smith', 'John', 'jsmith', to_date('01/01/1989', 'DD/MM/YYYY'), 'CEO of the company', null, 'President', 50, 5000, null);

insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (2, 'Nguyen', 'Lan', 'lnguyen', to_date('15/05/1990', 'DD/MM/YYYY'), 'Finance Manager', 1, 'Manager', 10, 1800, 5.0);

insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (3, 'Tâm', 'Nguyễn Văn', 'tvnguyen', to_date('10/06/1991', 'DD/MM/YYYY'), 'Sales Director', 1, 'Giám đốc', 31, 2500, 10.5);

insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (4, 'Snow', 'Alice', 'asnow', to_date('20/08/1991', 'DD/MM/YYYY'), 'Top Sales Rep', 3, 'Sales Rep', 31, 1400, 15.0);

insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (5, 'Stark', 'Sansa', 'sstark', to_date('15/05/1991', 'DD/MM/YYYY'), 'Operations Clerk', 2, 'Clerk', 42, 1200, null);

insert into s_emp (id, last_name, first_name, userid, start_date, comments, manager_id, title, dept_id, salary, commission_pct) 
values (6, 'Doe', 'Jane', 'jdoe', to_date('05/01/1992', 'DD/MM/YYYY'), 'Finance Clerk', 2, 'Clerk', 10, 950, null);

commit;
select * from s_emp;

-- 5. BẢNG S_CUSTOMER
insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (1, 'Vinamilk', '0901234567', '10 Tan Trao', 'Ho Chi Minh', 'HCM', 'Vietnam', '700000', 'EXCELLENT', 4, 1, 'VIP Client');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (2, 'Apple Inc', '+1-800-275-2273', '1 Apple Park Way', 'Cupertino', 'CA', 'USA', '95014', 'EXCELLENT', 4, 3, 'Tech Giant');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (3, 'Samsung', '+82-2-2053-3000', '129 Samsung-ro', 'Suwon', 'Gyeonggi', 'South Korea', '16677', 'GOOD', 4, 1, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (4, 'Toyota', '+81-565-28-2121', '1 Toyota-Cho', 'Toyota City', 'Aichi', 'Japan', '471-8571', 'EXCELLENT', 4, 1, 'Automotive');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (5, 'BMW', '+49-89-1250-1600', 'Petuelring 130', 'Munich', 'Bavaria', 'Germany', '80809', 'GOOD', 4, 2, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (6, 'L Oreal', '+33-1-40-20-60-00', '14 Rue Royale', 'Paris', 'IDF', 'France', '75008', 'GOOD', 4, 2, 'Cosmetics');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (7, 'Ferrari', '+39-0536-949111', 'Via Abetone Inferiore 4', 'Maranello', 'MO', 'Italy', '41053', 'POOR', 4, 2, 'Sports Cars');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (8, 'Tesco', '+44-800-505555', 'Shire Park', 'Welwyn', 'Herts', 'UK', 'AL7 1GA', 'GOOD', 4, 2, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (9, 'Zara', '+34-900-814900', 'Edificio Inditex', 'Arteixo', 'Coruna', 'Spain', '15142', 'EXCELLENT', 4, 2, 'Fashion');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (10, 'BHP', '+61-1300-55-4757', '171 Collins St', 'Melbourne', 'VIC', 'Australia', '3000', 'GOOD', 4, 6, 'Mining');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (11, 'Shopify', '+1-888-746-7439', '151 O Connor St', 'Ottawa', 'ON', 'Canada', 'K2P 2L8', 'EXCELLENT', 4, 3, 'E-commerce');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (12, 'Petrobras', '+55-800-728-9001', 'Av. Republica', 'Rio', 'RJ', 'Brazil', '20031', 'POOR', 4, 4, 'Energy');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (13, 'America Movil', '+52-55-2581-3700', 'Lago Zurich 245', 'Mexico City', 'CDMX', 'Mexico', '11529', 'GOOD', 4, 3, 'Telecom');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (14, 'MercadoLibre', '+54-11-4640-8000', 'Arias 3751', 'Buenos Aires', 'BA', 'Argentina', 'C1430', 'GOOD', 4, 4, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (15, 'Tata Group', '+91-22-6665-8282', 'Bombay House', 'Mumbai', 'MH', 'India', '400001', 'EXCELLENT', 4, 1, 'Conglomerate');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (16, 'Alibaba', '+86-571-8502-2088', '969 West Wen Yi Road', 'Hangzhou', 'Zhejiang', 'China', '311121', 'EXCELLENT', 4, 1, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (17, 'Gazprom', '+7-495-719-30-01', 'Nametkina St 16', 'Moscow', 'MOW', 'Russia', '117997', 'POOR', 4, 2, 'Gas');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (18, 'Naspers', '+27-21-406-2121', '40 Heerengracht', 'Cape Town', 'WC', 'South Africa', '8001', 'GOOD', 4, 5, null);

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (19, 'Suez Canal Auth', '+20-64-3392000', 'Irshad Bldg', 'Ismailia', 'IS', 'Egypt', '41515', 'GOOD', 4, 5, 'Transport');

insert into s_customer (id, name, phone, address, city, state, country, zip_code, credit_rating, sale_rep_id, region_id, comments) 
values (20, 'PTT', '+66-2-537-2000', '555 Vibhavadi Rangsit', 'Bangkok', 'BKK', 'Thailand', '10900', 'EXCELLENT', 4, 1, 'Oil');

commit;
select * from s_customer;
-- 6. BẢNG S_WAREHOUSE
insert into s_warehouse (id, region_id, address, city, state, country, zip_code, phone, manager_id) 
values (1, 3, '123 Tech Blvd', 'San Francisco', 'CA', 'USA', '94105', '+1-415-555-1234', 1);

insert into s_warehouse (id, region_id, address, city, state, country, zip_code, phone, manager_id) 
values (2, 1, '12 Le Loi', 'Ho Chi Minh', 'HCM', 'Vietnam', '700000', '+84-90-123-4567', 2);

commit;
select * from s_warehouse;

-- 7. BẢNG S_IMAGE
insert into s_image (id, format, use_filename, filename, image) 
values (1, 'JPEG', 'Y', 'pro_ski.jpg', null);

insert into s_image (id, format, use_filename, filename, image) 
values (2, 'PNG', 'Y', 'bicycle_city.png', null);

commit;
select * from s_image;

-- 8. BẢNG S_LONGTEXT
insert into s_longtext (id, use_filename, filename, text) 
values (1, 'N', null, 'Đây là mô tả chi tiết rất dài về sản phẩm ván trượt tuyết chuyên nghiệp...');

insert into s_longtext (id, use_filename, filename, text) 
values (2, 'N', null, 'Mô tả chi tiết về xe đạp leo núi với khung nhôm siêu nhẹ, phuộc nhún...');

commit;
select * from s_longtext;

-- 9. BẢNG S_PRODUCT

insert into s_product (id, name, short_desc, longtext_id, image_id, suggested_whlsl_price, whlsl_units) 
values (10, 'Pro Ski Master', 'High quality water ski for professionals', 1, 1, 500, 'Pair');

insert into s_product (id, name, short_desc, longtext_id, image_id, suggested_whlsl_price, whlsl_units) 
values (20, 'Mountain Bicycle', 'Off-road bicycle 21 speed', 2, 2, 300, 'Piece');

insert into s_product (id, name, short_desc, longtext_id, image_id, suggested_whlsl_price, whlsl_units) 
values (30, 'City Bicycle', 'Everyday commuter bicycle', null, null, 200, 'Piece');

insert into s_product (id, name, short_desc, longtext_id, image_id, suggested_whlsl_price, whlsl_units) 
values (40, 'Pro Helmet', 'Safety helmet', null, null, 50, 'Piece');

commit;
select * from s_product;


-- 10. BẢNG S_ORD

insert into s_ord (id, customer_id, date_ordered, date_shipped, sale_rep_id, total, payment_type, order_filled) 
values (101, 1, to_date('01/01/2026', 'DD/MM/YYYY'), to_date('05/01/2026', 'DD/MM/YYYY'), 4, 150000, 'CREDIT', 'Y');

insert into s_ord (id, customer_id, date_ordered, date_shipped, sale_rep_id, total, payment_type, order_filled) 
values (102, 1, to_date('15/01/2026', 'DD/MM/YYYY'), to_date('20/01/2026', 'DD/MM/YYYY'), 4, 50000, 'CASH', 'Y');

insert into s_ord (id, customer_id, date_ordered, date_shipped, sale_rep_id, total, payment_type, order_filled) 
values (103, 2, to_date('20/01/2026', 'DD/MM/YYYY'), null, 4, 80000, 'CREDIT', 'N');

insert into s_ord (id, customer_id, date_ordered, date_shipped, sale_rep_id, total, payment_type, order_filled) 
values (104, 3, to_date('10/02/2026', 'DD/MM/YYYY'), null, 4, 500, 'CASH', 'N');

commit;
select * from s_ord;

-- 11. BẢNG S_ITEM
insert into s_item (ord_id, item_id, product_id, price, quantity, quantity_shipped) 
values (101, 1, 10, 500, 200, 200);

insert into s_item (ord_id, item_id, product_id, price, quantity, quantity_shipped) 
values (101, 2, 20, 300, 166, 166);

insert into s_item (ord_id, item_id, product_id, price, quantity, quantity_shipped) 
values (102, 1, 30, 200, 250, 250);

insert into s_item (ord_id, item_id, product_id, price, quantity, quantity_shipped) 
values (103, 1, 20, 300, 266, 0);

insert into s_item (ord_id, item_id, product_id, price, quantity, quantity_shipped) 
values (104, 1, 40, 50, 10, 0);

commit;
select * from s_item;
-- 12. BẢNG S_INVENTORY

insert into s_inventory (product_id, warehouse_id, amount_in_stock, reorder_point, max_in_stock, out_of_stock_explanation, restock_date) 
values (10, 1, 150, 20, 500, null, to_date('01/03/2026', 'DD/MM/YYYY'));

insert into s_inventory (product_id, warehouse_id, amount_in_stock, reorder_point, max_in_stock, out_of_stock_explanation, restock_date) 
values (20, 2, 85, 10, 200, null, to_date('15/02/2026', 'DD/MM/YYYY'));

insert into s_inventory (product_id, warehouse_id, amount_in_stock, reorder_point, max_in_stock, out_of_stock_explanation, restock_date) 
values (30, 2, 0, 15, 300, 'Lỗi vận chuyển đường biển', null);

commit;
select * from s_inventory;

-- Bài 2
-- câu 1
SELECT name AS "Ten khach hang", 
 id AS "Ma khach hang" 
FROM s_customer 
ORDER BY id DESC;

-- câu 2
SELECT first_name || ' ' || last_name AS "Employees", 
 dept_id 
FROM s_emp 
WHERE dept_id IN (10, 50) 
ORDER BY first_name; 

-- câu 3
SELECT last_name, first_name 
FROM s_emp 
WHERE first_name LIKE '%S%' 
 OR last_name LIKE '%S%';

-- câu 4
SELECT userid, start_date 
FROM s_emp 
WHERE start_date BETWEEN TO_DATE('14/05/1990','DD/MM/YYYY')  AND TO_DATE('26/05/1991','DD/MM/YYYY');

-- câu 5
SELECT last_name, salary 
FROM s_emp 
WHERE salary BETWEEN 1000 AND 2000;

-- câu 6
SELECT last_name || ' ' || first_name AS "Employee Name", 
salary AS "Monthly Salary" 
FROM s_emp 
WHERE dept_id IN (31, 42, 50) 
AND salary > 1350;

-- câu 7
SELECT last_name, start_date 
FROM s_emp 
WHERE TO_CHAR(start_date, 'YYYY') = '1991'; 

-- câu 8
SELECT last_name, first_name 
FROM s_emp 
WHERE id NOT IN (SELECT DISTINCT manager_id 
FROM s_emp 
WHERE manager_id IS NOT NULL); 

-- câu 9
SELECT name 
FROM s_product 
WHERE name LIKE 'Pro%' 
ORDER BY name ASC;

-- câu 10
SELECT name, short_desc 
FROM s_product 
WHERE LOWER(short_desc) LIKE '%bicycle%';

-- câu 11
SELECT short_desc 
FROM s_product;

-- câu 12
SELECT last_name || ' ' || first_name || ' (' || title || ')' AS "Nhan vien" 
FROM s_emp;

-- bài 2
-- câu 1
SELECT id, 
last_name, 
ROUND(salary * 1.15, 2) AS "Luong moi" 
FROM s_emp;

-- câu 2
SELECT last_name, 
start_date, 
TO_CHAR( 
NEXT_DAY(ADD_MONTHS(start_date, 6), 'MONDAY'), 'Ddspth "of" Month YYYY') AS "Ngay xet tang luong" 
FROM s_emp; 

-- câu 3
SELECT name 
FROM s_product 
WHERE LOWER(name) LIKE '%ski%';

-- câu 4
SELECT last_name, 
ROUND(MONTHS_BETWEEN(SYSDATE, start_date)) AS "So thang tham  nien" 
FROM s_emp 
ORDER BY MONTHS_BETWEEN(SYSDATE, start_date) ASC;

-- câu 5
SELECT COUNT(DISTINCT manager_id) AS "So nguoi quan ly" 
FROM s_emp 
WHERE manager_id IS NOT NULL;

-- câu 6
SELECT MAX(total) AS "Highest", MIN(total) AS "Lowest" 
FROM s_ord;

-- bài 4
-- câu 1
SELECT p.name, 
 p.id, 
 i.quantity AS "ORDERED" 
FROM s_product p, s_item i 
WHERE p.id = i.product_id 
 AND i.ord_id = 101;

-- câu 2
SELECT c.id AS "Ma khach hang", 
 o.id AS "Ma don hang" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id(+) 
ORDER BY c.id; 

-- câu 3
SELECT o.customer_id, 
 i.product_id, 
 i.quantity 
FROM s_ord o, s_item i 
WHERE o.id = i.ord_id 
 AND o.total > 100000;

-- bài 5
-- câu 1
SELECT manager_id AS "Ma quan ly", 
 COUNT(id) AS "So nhan vien" 
FROM s_emp 
WHERE manager_id IS NOT NULL 
GROUP BY manager_id 
ORDER BY manager_id;

-- câu 2
SELECT manager_id AS "Ma quan ly", COUNT(id) AS "So nhan vien" 
FROM s_emp 
WHERE manager_id IS NOT NULL 
GROUP BY manager_id 
HAVING COUNT(id) >= 20;

-- câu 3
SELECT r.id AS "Ma vung", 
 r.name AS "Ten vung", 
 COUNT(d.id) AS "So phong ban" 
FROM s_region r, s_dept d 
WHERE r.id = d.region_id 
GROUP BY r.id, r.name 
ORDER BY r.id;

-- câu 4
SELECT c.name AS "Ten khach hang", 
 COUNT(o.id) AS "So don dat hang" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
ORDER BY c.name;

-- câu 5
SELECT c.name, COUNT(o.id) AS "So don hang" 
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
HAVING COUNT(o.id) = ( 
 SELECT MAX(COUNT(id)) 
 FROM s_ord 
 GROUP BY customer_id 
);

-- câu 6
SELECT c.name, SUM(o.total) AS "Tong tien" 
FROM s_customer c, s_ord o 
WHERE c.id = o.customer_id 
GROUP BY c.id, c.name 
HAVING SUM(o.total) = ( 
 SELECT MAX(SUM(total)) 
 FROM s_ord 
 GROUP BY customer_id 
);

-- bài 6
-- câu 1
SELECT last_name, first_name, start_date 
FROM s_emp 
WHERE dept_id IN (SELECT dept_id FROM s_emp WHERE first_name = 'Lan')  AND first_name != 'Lan';

-- câu 2
SELECT id, last_name, first_name, userid 
FROM s_emp 
WHERE salary > (SELECT AVG(salary) FROM s_emp);

-- câu 3
SELECT id, last_name, first_name 
FROM s_emp 
WHERE salary > (SELECT AVG(salary) FROM s_emp) 
 AND (UPPER(first_name) LIKE '%L%' 
 OR UPPER(last_name) LIKE '%L%');

-- câu 4
SELECT c.name 
FROM s_customer c 
WHERE NOT EXISTS ( 
 SELECT 1 
 FROM s_ord o 
 WHERE o.customer_id = c.id 
);

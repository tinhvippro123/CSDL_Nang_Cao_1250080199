-- phiếu bài tập 1
-- a
create or replace trigger trg_Nhap
before insert on Nhap
for each row
declare
    v_dem number := 0;
begin
    if :NEW.SoLuongN <= 0 or :NEW.DonGiaN <= 0 then
        raise_application_error(-20001, 'Lỗi: Số lượng nhập hoặc đơn giá nhập <= 0');
    end if;

    select count(*) into v_dem from SanPham where MaSP = :NEW.MaSP;
    
    if v_dem = 0 then
        raise_application_error(-20002, 'Lỗi: mã sản phẩm không có trong hệ thống');
    end if;

    update SanPham 
    set SoLuong = SoLuong + :NEW.SoLuongN
    where MaSP = :NEW.MaSP;
end trg_Nhap;

-- test câu a
-- Test 1: Cố tình nhập số lượng âm (Sẽ văng lỗi -20001)
insert into Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) values ('HDN01', 'SP01', -5, 100000);

-- Test 2: Cố tình nhập MaSP không có thật (Sẽ văng lỗi -20002)
insert into Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) values ('HDN01', 'SP99', 10, 100000);

-- Test 3: Dữ liệu chuẩn. Nhập 20 cái. Kho (SP01) sẽ từ 100 lên 120.
insert into Nhap (SoHDN, MaSP, SoLuongN, DonGiaN) values ('HDN01', 'SP01', 20, 100000);

-- kiểm tra lại kho
select MaSP, SoLuong from SanPham where MaSP = 'SP01'; -- Quét lại xem kho nhảy số chưa


-- b
create or replace trigger trg_xuat
before insert on Xuat
for each row
declare
    v_dem number := 0;
    v_soluong_ton number := 0;
begin
    select count(*) into v_dem from SanPham where MaSP = :NEW.MaSP;
    
    if v_dem = 0 then
        raise_application_error(-20001, 'Lỗi: mã sản phẩm không có trong hệ thống');
    end if;

    select SoLuong into v_soluong_ton from SanPham where MaSP = :NEW.MaSP;
    
    if :NEW.SoLuongX > v_soluong_ton then
        raise_application_error(-20002, 'Lỗi: Số lượng trong kho không đủ để xuất');
    end if;

    update SanPham 
    set SoLuong = SoLuong - :NEW.SoLuongX
    where MaSP = :NEW.MaSP;
end trg_xuat;
/

-- test câu b
-- Test 1: Xuất mã SP tào lao (Văng lỗi -20001)
insert into Xuat (SoHDX, MaSP, SoLuongX) values ('HDX01', 'SP99', 10);

-- Test 2: Xuất lố số lượng tồn. Kho đang 120, đòi xuất 200 (Văng lỗi -20002)
insert into Xuat (SoHDX, MaSP, SoLuongX) values ('HDX01', 'SP01', 200);

-- Test 3: Dữ liệu chuẩn. Xuất 30 cái. Kho (SP01) sẽ từ 120 tụt xuống 90.
insert into Xuat (SoHDX, MaSP, SoLuongX) values ('HDX01', 'SP01', 30);

-- Kiểm tra lại kho
select MaSP, SoLuong from SanPham where MaSP = 'SP01';

-- c
create or replace trigger trg_XoaXuat
after delete on Xuat
for each row
begin
    -- Hoàn trả số lượng khi xóa bản ghi xuất
    update SanPham 
    set SoLuong = SoLuong + :OLD.SoLuongX
    where MaSP = :OLD.MaSP;
end trg_XoaXuat;

-- test câu c
delete from Xuat where SoHDX = 'HDX01' and MaSP = 'SP01';
select MaSP, SoLuong from SanPham where MaSP = 'SP01';

-- phiếu bài tập 2
-- Chạy cái này đầu tiên để tạo biến đếm toàn cục cho mấy cái Compound Trigger nhe
create or replace package pkg_dem_dong as
    so_dong_thay_doi number := 0;
end pkg_dem_dong;
/

-- a
create or replace trigger trg_CapNhatXuat
for update on Xuat
compound trigger
    v_tonkho number;

    before statement is
    begin
        pkg_dem_dong.so_dong_thay_doi := 0;
    end before statement;

    before each row is
    begin
        pkg_dem_dong.so_dong_thay_doi := pkg_dem_dong.so_dong_thay_doi + 1;
        
        if pkg_dem_dong.so_dong_thay_doi > 1 then
            raise_application_error(-20001, 'Lỗi: Chỉ được cập nhất 1 bản ghi mỗi lần thôi');
        end if;

        if :NEW.SoLuongX <> :OLD.SoLuongX then
            select SoLuong into v_tonkho from SanPham where MaSP = :NEW.MaSP;
            
            if v_tonkho < (:NEW.SoLuongX - :OLD.SoLuongX) then
                raise_application_error(-20002, 'Lỗi: hàng trong kho không đủ để xuất');
            end if;
        end if;
    end before each row;

    after each row is
    begin
        if :NEW.SoLuongX <> :OLD.SoLuongX then
            update SanPham
            set SoLuong = SoLuong - (:NEW.SoLuongX - :OLD.SoLuongX)
            where MaSP = :NEW.MaSP;
        end if;
    end after each row;

end trg_CapNhatXuat;
/

-- test câu a
-- Test 1: Đang xuất 10 cái, sửa thành xuất lố lên 1000 cái (Sẽ văng lỗi -20002 vì kho không đủ đền)
update Xuat set SoLuongX = 1000 where SoHDX = 'HDX01' and MaSP = 'SP01';

-- Test 2: Hợp lệ. Đang xuất 10, đổi ý lên xuất 15 (chênh lệch 5 cái). 
update Xuat set SoLuongX = 15 where SoHDX = 'HDX01' and MaSP = 'SP01';
select MaSP, SoLuong from SanPham where MaSP = 'SP01';

-- b
create or replace trigger trg_CapNhatNhap
for update on Nhap
compound trigger

    before statement is
    begin
        pkg_dem_dong.so_dong_thay_doi := 0;
    end before statement;

    before each row is
    begin
        pkg_dem_dong.so_dong_thay_doi := pkg_dem_dong.so_dong_thay_doi + 1;
        
        if pkg_dem_dong.so_dong_thay_doi > 1 then
            raise_application_error(-20001, 'Lỗi: Chỉ được update 1 đơn nhập thôi');
        end if;
    end before each row;

    after each row is
    begin
        if :NEW.SoLuongN <> :OLD.SoLuongN then
            update SanPham
            set SoLuong = SoLuong + (:NEW.SoLuongN - :OLD.SoLuongN)
            where MaSP = :NEW.MaSP;
        end if;
    end after each row;

end trg_CapNhatNhap;
/

-- test câu b
update Nhap set SoLuongN = 60 where SoHDN = 'HDN02' and MaSP = 'SP01';
 -- Kiểm tra lại kho, sẽ nhảy lên 10 cái
select MaSP, SoLuong from SanPham where MaSP = 'SP01';

-- c
create or replace trigger trg_XoaNhap
after delete on Nhap
for each row
begin
    update SanPham
    set SoLuong = SoLuong - :OLD.SoLuongN
    where MaSP = :OLD.MaSP;
end trg_XoaNhap;
/

-- test câu c
delete from Nhap where SoHDN = 'HDN02' and MaSP = 'SP01';
-- Kiểm tra lại kho, sẽ bị trừ văng 60 cái
select MaSP, SoLuong from SanPham where MaSP = 'SP01';

-- phiếu bài tập 3
-- a
create or replace trigger trg_DatPhong
before insert on HoaDon
for each row
declare
    v_kh_ton_tai number;
    v_phong_ton_tai number;
    v_trangthai_phong Phong.TrangThai%TYPE;
    v_max_nguoi Phong.SoNguoiToiDa%TYPE;
    v_gia_ngay Phong.GiaTheoNgay%TYPE;
begin
    select count(*) into v_kh_ton_tai from KhachHang where MaKH = :NEW.MaKH;
    if v_kh_ton_tai = 0 then 
        raise_application_error(-20001, 'Lỗi: Khách hàng chưa đăng ký thông tin'); 
    end if;

    select count(*) into v_phong_ton_tai from Phong where MaPhong = :NEW.MaPhong;
    if v_phong_ton_tai = 0 then 
        raise_application_error(-20002, 'Lỗi: Mã phòng không tồn tại trong eh65 thống'); 
    else
        select TrangThai, SoNguoiToiDa, GiaTheoNgay 
        into v_trangthai_phong, v_max_nguoi, v_gia_ngay 
        from Phong where MaPhong = :NEW.MaPhong;
        
        if v_trangthai_phong != 'TRONG' then 
            raise_application_error(-20003, 'Lỗi: Phòng này đang có khách hoặc bảo trì'); 
        end if;
        if :NEW.SoNguoi > v_max_nguoi then 
            raise_application_error(-20004, 'Lỗi: Vượt quá số người tối đa của phòng'); 
        end if;
    end if;

    if :NEW.NgayNhan >= :NEW.NgayTra or :NEW.NgayNhan < trunc(sysdate) then
        raise_application_error(-20005, 'Lỗi: Ngày nhận/trả phòng ib5 sai cái logic');
    end if;

    :NEW.TongTien := (:NEW.NgayTra - :NEW.NgayNhan) * v_gia_ngay;

    update Phong set TrangThai = 'DA_THUE' where MaPhong = :NEW.MaPhong;
end;
/

-- b
create or replace trigger trg_CapNhatTrangThaiHD
before update of TrangThai on HoaDon
for each row
begin
    if :OLD.TrangThai in ('DA_TRA', 'HUY') then
        raise_application_error(-20001, 'Lỗi: Hoá đơn này đã đóng, miễn chỉnh sửa nhé');
    end if;

    if :OLD.TrangThai = 'CHO_NHAN' and :NEW.TrangThai not in ('DANG_O', 'HUY') then
        raise_application_error(-20002, 'Lỗi: Từ CHO_NHAN chỉ được đổi sang DANG_O hoặc HUY');
    end if;

    if :OLD.TrangThai = 'DANG_O' and :NEW.TrangThai != 'DA_TRA' then
        raise_application_error(-20003, 'Lỗi: Khách DANG_O thì chỉ có thể chuyển sang DA_TRA');
    end if;

    if :NEW.TrangThai = 'DA_TRA' then
        update Phong set TrangThai = 'TRONG' where MaPhong = :NEW.MaPhong;
        
        insert into LichSuPhong(MaLS, MaPhong, MaHD, NgayNhan, NgayTra, GhiChu)
        values (nvl((select max(to_number(MaLS)) from LichSuPhong), 0) + 1, :NEW.MaPhong, :NEW.MaHD, :NEW.NgayNhan, :NEW.NgayTra, 'Khach da out');
        
    elsif :NEW.TrangThai = 'HUY' then
        update Phong set TrangThai = 'TRONG' where MaPhong = :NEW.MaPhong;
    end if;
end;
/

-- c
create or replace trigger trg_SuaChiPhi
for insert or update on ChiPhiPhuThu
compound trigger
    v_dem number := 0;
    type t_mang_mahd is table of HoaDon.MaHD%type index by pls_integer;
    v_danh_sach_hd t_mang_mahd;
    v_chi_so pls_integer := 1;

    before statement is
    begin
        v_dem := 0;
        v_chi_so := 1;
        v_danh_sach_hd.delete;
    end before statement;

    before each row is
    begin
        v_dem := v_dem + 1;
        if v_dem > 5 then
            raise_application_error(-20001, 'Lỗi; Thêm tối đa 5 loại phí phụ thu 1 lúc thôi');
        end if;

        -- Check tiền hợp lệ
        if :NEW.SoTien <= 0 or :NEW.SoTien >= 50000000 then
            raise_application_error(-20002, 'Lỗi: Số tiền phụ thu không hợp lý');
        end if;
    end before each row;

    after each row is
        v_da_co boolean := false;
    begin
        for i in 1 .. v_danh_sach_hd.count loop
            if v_danh_sach_hd(i) = :NEW.MaHD then
                v_da_co := true; exit;
            end if;
        end loop;
        
        if not v_da_co then
            v_danh_sach_hd(v_chi_so) := :NEW.MaHD;
            v_chi_so := v_chi_so + 1;
        end if;
    end after each row;

    after statement is
        v_tong_goc number;
        v_tong_phu_thu number;
    begin
        for i in 1 .. v_danh_sach_hd.count loop
            -- Lấy tiền gốc của hóa đơn
            select (h.NgayTra - h.NgayNhan) * p.GiaTheoNgay 
            into v_tong_goc 
            from HoaDon h join Phong p on h.MaPhong = p.MaPhong
            where h.MaHD = v_danh_sach_hd(i);
            
            select nvl(sum(SoTien), 0) into v_tong_phu_thu 
            from ChiPhiPhuThu where MaHD = v_danh_sach_hd(i);
            
            update HoaDon 
            set TongTien = v_tong_goc + v_tong_phu_thu
            where MaHD = v_danh_sach_hd(i);
        end loop;
    end after statement;
end trg_SuaChiPhi;

-- d
create sequence SEQ_HD start with 1 increment by 1;

create or replace view vw_PhongTrong as
select MaPhong, LoaiPhong, GiaTheoGio, GiaTheoNgay, SoNguoiToiDa
from Phong
where TrangThai = 'TRONG';

create or replace trigger trg_vwPhongTrong_ins
instead of insert on vw_PhongTrong
for each row
declare
    v_mahd_moi varchar2(20);
    v_makh_random varchar2(20);
begin
    v_mahd_moi := 'HD' || to_char(SEQ_HD.nextval, 'FM0000');
    
    select min(MaKH) into v_makh_random from KhachHang; 

    insert into HoaDon (MaHD, MaKH, MaPhong, NgayNhan, NgayTra, SoNguoi, TrangThai)
    values (v_mahd_moi, v_makh_random, :NEW.MaPhong, trunc(sysdate), trunc(sysdate) + 1, 1, 'CHO_NHAN');
end;
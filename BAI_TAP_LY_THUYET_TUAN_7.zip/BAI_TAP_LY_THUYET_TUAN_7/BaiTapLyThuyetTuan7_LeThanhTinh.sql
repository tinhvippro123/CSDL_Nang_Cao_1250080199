create table KHOA(
    Makhoa varchar2(10) primary key,
    Tenkhoa nvarchar2(100),
    Dienthoai varchar2(10)
)

create table LOP(
    Malop varchar2(10) primary key,
    Tenlop nvarchar2(50),
    Khoa nvarchar2(50),
    Hedt nvarchar2(50),
    Namnhaphoc varchar2(15),
    Makhoa varchar2(10),
    constraint fk_LOP_KHOA foreign key (Makhoa) references KHOA(Makhoa)
)

-- bài 1
create or replace procedure sp_ThemKhoa(maKhoa in varchar2, tenKhoa in nvarchar2, dienThoai in varchar2)
as dem number := 0;
begin
    select count(*) into dem from KHOA where Tenkhoa = tenKhoa;
    if dem > 0 then
        DBMS_OUTPUT.PUT_LINE('Thông báo: Tên khoa đã tồn tại.');
    else
        insert into KHOA(Makhoa, Tenkhoa, Dienthoai)
        values(maKhoa, tenKhoa, dienThoai);
        commit;
        DBMS_OUTPUT.PUT_LINE('Thông báo: Thêm khoa thành công');
    end if;
end;


SET SERVEROUTPUT ON

-- test trường hợp 1
begin
    sp_themkhoa('CNTT', N'Công nghệ thông tin', '0123456789');
end;


-- test trường hợp 2
begin
    sp_themkhoa('CNTT1', N'Công nghệ thông tin', '0123456789');
end;

-- bài tập 2
create or replace procedure sp_ThemLop (
    maLop in varchar2, tenLop in nvarchar2, khoa in nvarchar2, 
    hedt in nvarchar2, namnhaphoc in number, maKhoa in varchar2
) as
    dem_lop number := 0;
    dem_khoa number := 0;
begin
    select count(*) into dem_lop from LOP where tenlop = tenlop;
    select count(*) into dem_khoa from KHOA where makhoa = makhoa;

    if dem_lop > 0 then
        DBMS_OUTPUT.PUT_LINE('Thông báo: Tên lớp đã tồn tại');
    elsif dem_khoa = 0 then
        DBMS_OUTPUT.PUT_LINE('Thông báo: Mã khoa không tồn tại trong bảng KHOA');
    else
        insert into LOP (malop, tenlop, khoa, hedt, namnhaphoc, makhoa)
        values (malop, tenlop, khoa, hedt, namnhaphoc, makhoa);
        commit;
        DBMS_OUTPUT.PUT_LINE('Thông báo: Thêm lớp thành công');
    end if;
end;


-- bài tập 3
create or replace procedure sp_ThemKhoa_out (
    maKhoa in varchar2, tenKhoa in nvarchar2, dienThoai in varchar2,
    ketqua out number
) as
    dem number;
begin
    select count(*) into dem from KHOA where Tenkhoa = tenKhoa;
    if dem > 0 then
        ketqua := 0;
    else
        insert into KHOA values (maKhoa, tenKhoa, dienThoai);
        commit;
        ketqua := 1;
    end if;
end;

-- test
declare
    ketqua number;
begin
    DBMS_OUTPUT.PUT_LINE('Trường hợp 1: Thêm khoa mới ');
    sp_ThemKhoa_out('CNTT', N'Khoa Công nghệ thông tin', '0123456789', ketqua);
    if ketqua = 0 then
        DBMS_OUTPUT.PUT_LINE('Kết quả = 0, tên khoa đã tồn tại, không thể thêm');
    else
        DBMS_OUTPUT.PUT_LINE('Kết quả = 1, thêm khoa thành công');
    end if;
    
    DBMS_OUTPUT.PUT_LINE('---------------------------------------------');
    
    DBMS_OUTPUT.PUT_LINE('Trường hợp 2: Thêm khoa bị trùng tên');
    sp_ThemKhoa_out('IT', N'Khoa Công nghệ thông tin', '0987654321', ketqua);
    if ketqua = 0 then
        DBMS_OUTPUT.PUT_LINE('Kết quả = 0, tên khoa đã tồn tại, không thể thêm');
    else
        DBMS_OUTPUT.PUT_LINE('Kết quả = 1, thêm khoa thành công');
    end if;
end;


-- bài tập 4
create or replace procedure sp_ThemLop_out (
    malop in varchar2, 
    tenlop in nvarchar2, 
    khoa in nvarchar2, 
    hedt in nvarchar2, 
    namnhaphoc in varchar2,
    maKhoa in varchar2,
    ketQua out number
) as
    dem_lop number; 
    dem_khoa number;
begin
    select count(*) into dem_lop from lop where tenlop = tenlop;
    select count(*) into dem_khoa from khoa where makhoa = makhoa;

    if dem_lop > 0 then
        ketqua := 0;
    elsif dem_khoa = 0 then
        ketqua := 1;
    else
        insert into lop values (malop, tenlop, khoa, hedt, namnhaphoc, makhoa);
        commit;
        ketQua := 2;
    end if;
end;

---------- phiếu bài tập 2
create table tblChucVu (
    MaCV varchar2(10) primary key, 
    TenCV nvarchar2(50)
);

create table tblNhanVien (
    MaNV varchar2(10) primary key, 
    MaCV varchar2(10),
    TenNV nvarchar2(50),
    NgaySinh date, 
    LuongCanBan number(10, 2), 
    NgayCong number(5, 2),
    PhuCap number(10, 2),
    constraint fk_macv foreign key (MaCV) references tblChucVu(macv)
);


-- C. Chèn dữ liệu mẫu 
-- Chức vụ
insert into tblChucVu (MaCV, TenCV) values ('GD', N'Giám đốc');
insert into tblChucVu (MaCV, TenCV) values ('PGD', N'Phó Giám đốc');
insert into tblChucVu (MaCV, TenCV) values ('TP', N'Trưởng phòng');
insert into tblChucVu (MaCV, TenCV) values ('NV', N'Nhân viên');

commit;
-- Nhân viên
insert into tblNhanVien (MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap) 
values ('NV01', 'GD', N'Lê Thanh Tính', TO_DATE('01/01/1980', 'DD/MM/YYYY'), 20000000, 22, 5000000);

insert into tblNhanVien (MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap) 
values ('NV02', 'TP', N'Nguyên Trọng Thuận', TO_DATE('15/05/1985', 'DD/MM/YYYY'), 15000000, 24, 3000000);

insert into tblNhanVien (MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap) 
values ('NV03', 'NV', N'Lê Ngọc Thuận', TO_DATE('20/10/1995', 'DD/MM/YYYY'), 8000000, 20, 1000000);

COMMIT;


-- a
create or replace procedure SP_Them_Nhan_Vien (
    manv in varchar2, 
    macv in varchar2, 
    tennv in nvarchar2, 
    ngaysinh in date, 
    luongcb in number, 
    ngaycong in number, 
    phucap in number
) as
    dem_cv number;
begin
    select count(*) into dem_cv 
    from tblChucVu 
    where MaCV = macv;

    if dem_cv > 0 then
        insert into tblNhanVien 
        values (manv, macv, tennv, ngaysinh, luongcb, ngaycong, phucap);

        commit;
        DBMS_OUTPUT.PUT_LINE('Thêm nhân viên thành công');
    else
        DBMS_OUTPUT.PUT_LINE('MaCV không tồn tại');
    end if;
end;

-- b
create or replace procedure SP_CapNhat_Nhan_Vien (
    manv in varchar2, 
    macv in varchar2, 
    tennv in varchar2, 
    ngaysinh in date, 
    luongcb in number, 
    ngaycong in number, 
    phucap in number
) as
    dem_cv number;
begin
    select count(*) into dem_cv 
    from tblChucVu 
    where MaCV = macv;

    if dem_cv > 0 then
        update tblNhanVien 
        set MaCV = macv, 
            TenNV = tennv, 
            NgaySinh = ngaysinh, 
            LuongCanBan = luongcb, 
            NgayCong = ngaycong, 
            PhuCap = phucap
        where MaNV = manv;

        commit;
        DBMS_OUTPUT.PUT_LINE('Cập nhật thành công');
    else
        DBMS_OUTPUT.PUT_LINE('MaCV không tồn tại');
    end if;
end;

-- c. Tính và hiển thị lương [cite: 63, 64]

create or replace procedure SP_LuongLN as
begin
    for rec in (select MaNV, TenNV, LuongCanBan, NgayCong, PhuCap from tblNhanVien) loop
        DBMS_OUTPUT.PUT_LINE('Nhan vien: ' || rec.TenNV || 
                             ' - Luong: ' || (rec.LuongCanBan * rec.NgayCong + rec.PhuCap));
    end loop;
end;

---------- phiếu bài tập 3
-- 1 and 2
create or replace procedure sp_them_nhan_vien1 (
    manv in varchar2, 
    macv in varchar2, 
    tennv in nvarchar2, 
    ngaysinh in date, 
    luongcb in number, 
    ngaycong in number, 
    phucap in number,
    ketqua out number
) as
    dem_nv number;
    dem_cv number;
begin
    select count(*) into dem_nv from tblNhanVien where manv = manv;
    select count(*) into dem_cv from tblChucVu where macv = macv;

    if dem_nv > 0 then
        ketqua := 0;
    elsif dem_cv = 0 then
        ketqua := 1;
    else
        insert into tblNhanVien 
        values (manv, macv, tennv, ngaysinh, luongcb, ngaycong, phucap);

        commit;
        ketqua := 2;
    end if;
end;

-- 3
create or replace procedure sp_capnhat_ngaysinh (
    manv in varchar2,
    ngaysinh in date,
    ketqua out number
) as
    dem number;
begin
    select count(*) into dem 
    from tblnhanvien 
    where manv = manv;
    
    if dem = 0 then
        ketqua := 0;
    else
        update tblnhanvien 
        set ngaysinh = ngaysinh 
        where manv = manv;

        commit;
        ketqua := 1;
    end if;
end;



















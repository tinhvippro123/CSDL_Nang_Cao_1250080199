-- Tạo bảng Hang
create table Hang (
    Mahang varchar2(10) primary key,
    Tenhang nvarchar2(50),
    Soluong number,
    Giaban number
);

-- Tạo bảng Hoadon
create table Hoadon (
    Mahd varchar2(10) primary key,
    Mahang varchar2(10) references Hang(Mahang),
    Soluongban number,
    Ngayban date
);

-- Thêm dữ liệu
insert into Hang values('H01', 'Dien thoai Nokia', 100, 1500000);
insert into Hang values ('H02', 'Laptop Dell', 50, 15000000);
commit;

select * from Hang

-- Phiếu bài tập 1
-- Bài 1
create or replace trigger trg_hoadon_insert
before insert on Hoadon
for each row
declare
    v_dem number := 0;
    v_so_luong_ton number := 0;
begin
    select count(*) into v_dem 
    from Hang 
    where Mahang = :NEW.Mahang;
    
    if v_dem = 0 then
        raise_application_error(-20001, 'Lỗi: Mã hàng này không tồn tại trong kho');
    end if;

    select Soluong into v_so_luong_ton
    from Hang
    where Mahang = :NEW.Mahang;

    if :NEW.Soluongban > v_so_luong_ton then
        raise_application_error(-20002, 'Lỗi: Số lượng tồn kho không đủ để bán.');
    end if;

    update Hang
    set Soluong = Soluong - :NEW.Soluongban
    where Mahang = :NEW.Mahang;
end;
/

-- test bài 1
-- Trường hợp 1: Thành công
-- Mua 10 chiếc H01 (Trong kho đang có 100, mua xong kho sẽ trừ đi còn 90), lúc đầu em insert nó là 100
insert into Hoadon values ('HD01', 'H01', 10, SYSDATE);
select * from Hang; 

-- Trường hợp 2: Báo lỗi do mã hàng không tồn tại
insert into Hoadon values ('HD02', 'H99', 5, SYSDATE); 

-- Trường hợp 3: Báo lỗi do mua quá số lượng tồn
-- H02 chỉ có 50 chiếc, nhưng mà mua tận 60. Sẽ báo lỗi -20002
insert into Hoadon values ('HD03', 'H02', 60, SYSDATE);

-- bài 2
create or replace trigger trg_hoadon_delete
after delete on Hoadon
for each row
begin
    update Hang
    set Soluong = Soluong + :OLD.Soluongban
    where Mahang = :OLD.Mahang;
end;
/

-- test bài 2:
-- Xóa hóa đơn HD01 mới tạo ở trên.
-- Hóa đơn này mua 10 chiếc H01. Xóa xong, kho sẽ đượAc cộng trả lại 10 chiếc (từ 90 lên lại 100).
delete from Hoadon where Mahd = 'HD01';

select * from Hang;

-- Bài 3
create or replace trigger trg_hoadon_update
before update on Hoadon
for each row
declare
    v_so_luong_ton number;
    v_chenh_lech number;
begin
    v_chenh_lech := :NEW.Soluongban - :OLD.Soluongban;

    if v_chenh_lech > 0 then
        select Soluong into v_so_luong_ton
        from Hang
        where Mahang = :NEW.Mahang;

        if v_chenh_lech > v_so_luong_ton then
            RAISE_APPLICATION_ERROR(-20003, 'LỗiL Kho không còn đủ hàng để tăng số lượng bán khi cập nhật hóa đơn.');
        end if;
    end if;

    update Hang
    set Soluong = Soluong - v_chenh_lech
    where Mahang = :NEW.Mahang;
end;
/

-- Test bài 3:
-- Đầu tiên thì mình sẽ chuẩn bị: Tạo 1 hóa đơn hợp lệ mới, xong rồi sẽ test
insert into Hoadon values ('HD04', 'H02', 10, SYSDATE);
-- Lúc này kho H02 sẽ bị trừ 10, còn 40 chiếc.

-- Trường hợp 1: Khách đổi ý, mua tăng lên 15 chiếc (Chênh lệch +5)
-- Kho H02 sẽ bị trừ thêm 5 chiếc (từ 40 xuống 35)
update Hoadon set Soluongban = 15 where Mahd = 'HD04';
select * from Hang;

-- Trường hợp 2: Khách đổi ý, giảm xuống còn 5 chiếc (Chênh lệch -10)
-- Kho H02 sẽ được cộng thêm 10 chiếc (từ 35 lên 45)
update Hoadon set Soluongban = 5 where Mahd = 'HD04';
select * from Hang;

-- Trường hợp 3: Lỗi do cập nhật số lượng lớn hơn hàng tồn kho
-- Hiện tại H02 còn 45 chiếc, sửa thành mua 100 chiếc thì sẽ báo lỗi -20003
update Hoadon set Soluongban = 100 where Mahd = 'HD04';

-- Phiếu bài tập 2:
CREATE TABLE Mathang ( 
 Mahang VARCHAR2(5) CONSTRAINT pk_mathang PRIMARY KEY, 
 Tenhang VARCHAR2(50) NOT NULL, 
 Soluong NUMBER(10) 
); 
CREATE TABLE Nhatkybanhang ( 
 Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,  Ngay DATE, 
 Nguoimua VARCHAR2(50), 
 Mahang VARCHAR2(5) REFERENCES Mathang(Mahang), 
 Soluong NUMBER(10), 
 Giaban NUMBER(15,2) 
); 
-- Dữ liệu mẫu Mathang 
INSERT INTO Mathang VALUES ('1','Hang A', 100); 
INSERT INTO Mathang VALUES ('2','Hang B', 200); 
INSERT INTO Mathang VALUES ('3','Hang C', 150); 
COMMIT;

-- a
create or replace trigger trg_nhatkybanhang_insert
after insert on Nhatkybanhang
for each row
begin
    update Mathang
    set Soluong = Soluong - :NEW.Soluong
    where Mahang = :NEW.Mahang;
end;
/

-- Test câu a
-- Kiểm tra số lượng kho ban đầu của 'Hang A' (đang là 100)
select * from Mathang where Mahang = '1';

-- Thực hiện bán 10 sản phẩm 'Hang A'
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
values (SYSDATE, 'Nguyen Van A', '1', 10, 50000);

-- Kiểm tra lại kho: 'Hang A' phải giảm xuống còn 90
select * from Mathang where Mahang = '1';

-- b
create or replace trigger trg_nhatkybanhang_update_so_luong
after update of Soluong on Nhatkybanhang
for each row
begin
    update Mathang
    set Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    where Mahang = :NEW.Mahang;
end;
/
select * from Nhatkybanhang
-- Test câu b
-- Lấy ID (là Stt) của dòng nhật ký vừa bán ở câu a.
-- Khách đổi ý, mua tăng lên thành 15 sản phẩm (tăng thêm 5)
update Nhatkybanhang set Soluong = 15 where Stt = 2;

-- Kiểm tra lại kho: 'Hang A' bị trừ thêm 5, còn 85
select * from Mathang where Mahang = '1';

-- Khách lại đổi ý, giảm xuống còn 5 sản phẩm (giảm đi 10 so với mức 15)
update Nhatkybanhang set Soluong = 5 where Stt = 2;

-- Kiểm tra lại kho: 'Hang A' được cộng trả lại 10, lên mức 95
select * from Mathang where Mahang = '1';

-- c
create or replace trigger trg_nky_insert_check
before insert on Nhatkybanhang
for each row
declare
    v_so_luong_ton number := 0;
    v_dem number := 0;
begin
    select count(*) into v_dem 
    from Mathang 
    where Mahang = :NEW.Mahang;
    
    if v_dem = 0 then
        RAISE_APPLICATION_ERROR(-20001, 'Mã hàng không hợp lệ hoặc không tồn tại.');
    end if;

    select Soluong into v_so_luong_ton 
    from Mathang 
    where Mahang = :NEW.Mahang;

    if :NEW.Soluong > v_so_luong_ton then
        RAISE_APPLICATION_ERROR(-20002, 'Lỗi: Số lượng tồn kho không đủ.');
    end if;

    update Mathang
    set Soluong = Soluong - :NEW.Soluong
    where Mahang = :NEW.Mahang;
end;
/

select * from mathang
-- Test câu c
-- Trường hợp 1: Lỗi do mua quá số lượng trong kho
-- 'Hang B' (mã '2') đang có 200 chiếc. Mua 300 chiếc sẽ văng lỗi -20002
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
values (SYSDATE, 'Le Thi B', '2', 300, 100000);

-- Trường hợp 2: Lỗi do mã hàng không tồn tại
-- Mua mã '99' không có trong kho sẽ văng ra lỗi -20001
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
values (SYSDATE, 'Le Thi B', '99', 10, 100000);

-- Trường hợp 3: Thành công
-- Mua 50 chiếc 'Hang B'. Kho sẽ giảm từ 200 xuống 150.
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) 
values (SYSDATE, 'Le Thi B', '2', 50, 100000);

select * from Mathang where Mahang = '2';


-- d
-- Tao [ackage để lưu biến đếm dùng chung cho cả phiên làm việc
create or replace package pkg_nhatky_state as
    g_row_count number := 0;
end pkg_nhatky_state;
/

-- Tiếp theo là viết trigger
create or replace trigger trg_nky_update_compound
for update on Nhatkybanhang
compound trigger
    before statement is
    begin
        pkg_nhatky_state.g_row_count := 0;
    end before statement;

    before each row is
    begin
        pkg_nhatky_state.g_row_count := pkg_nhatky_state.g_row_count + 1;
        
        if pkg_nhatky_state.g_row_count > 1 then
            RAISE_APPLICATION_ERROR(-20003, 'Lỗi: Chỉ được phép cập nhật 1 bản ghi mỗi lần.');
        end if;
    end before each row;
    
    after each row is
    begin
        update Mathang
        set Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
        where Mahang = :NEW.Mahang;
    end after each row;

end trg_nky_update_compound;
/

-- Test câu d
-- Trường hợp 1: UPDATE 1 dòng hợp lệ
-- Sửa lại số lượng của đơn hàng Stt = 12 (mua Hang B) thành 60
update Nhatkybanhang set Soluong = 60 where Stt = 12;
-- Kiểm tra kho: 'Hang B' giảm thêm 10, còn 140
select * from Mathang where Mahang = '2';

-- Trường hợp 2: Cố tình UPDATE từ 2 dòng trở lên -> Báo lỗi -20003
update Nhatkybanhang set Soluong = 10;

-- e
create or replace trigger trg_nky_delete_compound
for delete on Nhatkybanhang
compound trigger

    before statement is
    begin
        pkg_nhatky_state.g_row_count := 0;
    end before statement;

    before each row is
    begin
        pkg_nhatky_state.g_row_count := pkg_nhatky_state.g_row_count + 1;
        
        if pkg_nhatky_state.g_row_count > 1 then
            RAISE_APPLICATION_ERROR(-20004, 'Lỗi: Chỉ được xoá 1 bản ghi mỗi lần.');
        end if;
    end before each row;
    
    after each row is
    begin
        update Mathang
        set Soluong = Soluong + :OLD.Soluong
        where Mahang = :OLD.Mahang;
    end after each row;

end trg_nky_delete_compound;
/

select * from Nhatkybanhang
-- Test câu e
-- Trường hợp 1: Xóa 1 dòng hợp lệ (Trả lại kho)
-- Xóa đơn hàng Stt = 2 (mua 60 chiếc Hang B). 
delete from Nhatkybanhang where Stt = 12;
-- Kiểm tra kho: 'Hang B' được hoàn lại 60, từ 140 lên lại 200
select * from Mathang where Mahang = '2';

-- Trường hợp 2: Cố tình xóa tất cả các dòng cùng lúc -> Báo lỗi -20004
delete from Nhatkybanhang;

-- f
create or replace trigger trg_nky_update_nangcao
for update of Soluong on Nhatkybanhang
compound trigger
    
    v_so_luong_ton number;
    v_chenh_lech number;

    before statement is
    begin
        pkg_nhatky_state.g_row_count := 0;
    end before statement;

    before each row is
    begin
        pkg_nhatky_state.g_row_count := pkg_nhatky_state.g_row_count + 1;
        if pkg_nhatky_state.g_row_count > 1 then
            RAISE_APPLICATION_ERROR(-20005, 'Lỗi: Chỉ được cập nhật 1 dòng.');
        end if;

        if :NEW.Soluong = :OLD.Soluong then
            RAISE_APPLICATION_ERROR(-20006, 'Thông báo: Số lượng không đổi, không cần cập nhật.');
        end if;

        v_chenh_lech := :NEW.Soluong - :OLD.Soluong;
        if v_chenh_lech > 0 then
            select Soluong into v_so_luong_ton from Mathang where Mahang = :NEW.Mahang;
            
            if v_chenh_lech > v_so_luong_ton then
                RAISE_APPLICATION_ERROR(-20007, 'Lỗi: Kho không đủ hàng để tăng số lượng mua');
            end if;
        end if;
    end before each row;

    after each row is
    begin
        update Mathang
        set Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
        where Mahang = :NEW.Mahang;
    end after each row;

end trg_nky_update_nangcao;
/

-- g
create or replace procedure proc_xoa_mathang (p_mahang in varchar2)
is
    v_dem number := 0;
begin
    select count(*) into v_dem 
    from Mathang 
    where Mahang = p_mahang;

    if v_dem = 0 then
        DBMS_OUTPUT.PUT_LINE('Thông báo: Mã hàng ' || p_mahang || ' không tồn tại.');
    else
        delete from Nhatkybanhang where Mahang = p_mahang;
        delete from Mathang where Mahang = p_mahang;
        
        DBMS_OUTPUT.PUT_LINE('Đã xoá mã hàng ' || p_mahang || ' và các giao dịch.');
        commit;
    end if;
end proc_xoa_mathang;
/

-- h
create or replace function fn_tongtien_tenhang (p_tenhang in varchar2)
return number
is
    v_tong_tien number := 0;
begin
    select sum(nk.Soluong * nk.Giaban) into v_tong_tien
    from Nhatkybanhang nk
    join Mathang mh on nk.Mahang = mh.Mahang
    where mh.Tenhang = p_tenhang;

    return NVL(v_tong_tien, 0);
end fn_tongtien_tenhang;
/

-- Test câu h
-- Thêm dữ liệu để có cái tính tổng
-- Bán thêm 2 đơn 'Hang C'
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) values (SYSDATE, 'Khach 1', '3', 5, 20000);
insert into Nhatkybanhang (Ngay, Nguoimua, Mahang, Soluong, Giaban) values (SYSDATE, 'Khach 2', '3', 10, 20000);

-- Tổng tiền 'Hang C' phải là: (5 * 20000) + (10 * 20000) = 300000
select fn_tongtien_tenhang('Hang C') as TongTien_HangC from DUAL;

-- Test với mặt hàng chưa bán được cái nào ('Hang A') -> Phải trả về 0
select fn_tongtien_tenhang('Hang A') as TongTien_KhongCo from DUAL;







